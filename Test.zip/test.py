filename = "hello.txt"

print(filename.strip(".txt"))