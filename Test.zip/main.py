from argparse import ArgumentParser
from fileinput import filename
from getpass import getpass
import json
from sys import stderr
from os.path import exists
from key_generator import KeyGenerator
from Cipher import Cipher
import binascii


def print_err(*args, **kwargs):
    print(*args, file=stderr, **kwargs)
    exit(1)


class Args:
    ''' Parses all the arguments and returns a dictionary. '''
    def get_args():
        parser = ArgumentParser()
        subparser = parser.add_mutually_exclusive_group()
        subparser.add_argument(
            "-e", "--encrypt", help="Encrypts the file specified", nargs='+')
        subparser.add_argument(
            "-d", "--decrypt", help="Decrypts the file specified", nargs='+')
        subparser.add_argument(
            "-s", "--search", help="Search for a specific keyword in the encrypted files")
        parser.add_argument(
            "-j", "--json", help="Output the data to stdout as a JSON Object", action='store_true')
        args = parser.parse_args()
        return vars(args)


class File_handling:

    def saveResultsToFile(dest_file, results, mode):
        try:
            file = open(dest_file, 'w')
        except IOError:
            print("Error: Can't create the \"" + dest_file + "\" file.")
        with file:
            counter = 0
            char_tup = ""
            for r in results:
                if mode == "-e":
                    file.write(r)
                else:
                    for c in r:
                        char_tup += c
                        counter += 1
                        if(counter == 2):
                            value = int(char_tup, 16)
                            if value != 0:
                                char_tup = chr(value)
                                file.write(char_tup)
                            counter = 0
                            char_tup = ""

    
    def getSrcFromFile(src_file, mode):
        try:
            with open(src_file, 'r') as file:
                # file = open(src_file, 'r')
                hex_strings = []
                counter = 0
                i = -1
                while True:
                    c = file.read(1)
                    if not c:
                        break
                    if counter % 16 == 0:
                        hex_strings.append("")
                        i += 1
                    if mode == "-e":
                        c = format(ord(c), "02x")
                        counter += 1
                    counter += 1
                    hex_strings[i] += c

                if i < 0:
                    raise ValueError("Error: the source file is empty!")
                hex_strings[i] = format(int(hex_strings[i], 16), "016x")
                return hex_strings
        except IOError:
            print_err("Error: Can't open the \"" + src_file + "\" file.")

        
    def saveMetaData(file, salt, key):
        metadata = {
            "Encodedsalt": str(binascii.hexlify(salt))[2:-1],
            "Salt": str(salt)[2:-1],
            "Key": str(key)[2:-1],
            "searchTerm": []
        }

        out_file = open(f".fenc-meta.{file}", "w")
        json.dump(metadata, out_file, indent=1)
        out_file.close()



if __name__ == "__main__":

    # A Dictionary object of all the arguments
    args = Args.get_args()
    _pass = getpass().encode()

    mode = "-e" if args["encrypt"] else "-d"
    names = args["encrypt"] if args["encrypt"] else args["decrypt"]
    _json = args["json"]

    List = [str(file_name).strip().replace(',','') for file_name in names]

    _meta = {}

    # file_handling = File_handling()
    for each in List:
        Key_Gen = KeyGenerator(each, _pass, mode)
        # File Handling
        cipher = Cipher(Key_Gen)
        file_name = each.strip()
        src = File_handling.getSrcFromFile(file_name, mode)
        results = []
        
        for s in src:
            if mode == "-e":
                results.append(cipher.encrypt(s))
            else:
                results.append(cipher.decrypt(s))

        if mode == "-e":
            File_handling.saveResultsToFile(file_name, results, mode)
            salt, key = Key_Gen.getSaltAndKey()
            File_handling.saveMetaData(file_name, salt, key)
        else:
            file_name = file_name.replace("cipher", "plain")
            File_handling.saveResultsToFile(file_name, results, mode)

        _meta[file_name] = ''.join(results)
    # # Encryption 
    # cipher = Cipher(args['json'])
    # if args["encrypt"] == None and args["decrypt"] == None:
    #     print("File is not Specified")
    # else:
    #     cipher.check_if_file_exists(args['encrypt'])
    print(_meta)