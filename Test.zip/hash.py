from secrets import token_bytes
from coincurve import PublicKey 
from sha3 import keccak_256
import threading
#import multiprocessing




def hashing(n):
    for i in range(n):
        private_key = keccak_256(token_bytes(32)).digest()
        public_key = PublicKey.from_valid_secret(private_key).format(compressed=False)[1:]
        addr = keccak_256(public_key).digest()[-20:]
        print("Private Key: ", private_key.hex()+ "\nEth Addr 0x" + addr.hex())

if __name__ == "__main__":

   # n = int(input("Enter the loop Number:"))

    t1 = threading.Thread(target=hashing, args=(10000,))
    t2 = threading.Thread(target=hashing, args=(10000,))
    t3 = threading.Thread(target=hashing, args=(10000,))
    t4 = threading.Thread(target=hashing, args=(10000,))
    t5 = threading.Thread(target=hashing, args=(10000,))
    t6 = threading.Thread(target=hashing, args=(10000,))
    t7 = threading.Thread(target=hashing, args=(10000,))
    t8 = threading.Thread(target=hashing, args=(10000,))
    t9 = threading.Thread(target=hashing, args=(10000,))
    t10 = threading.Thread(target=hashing, args=(10000,))


    t1.start()
    t2.start()
    t3.start()
    t4.start()
    t5.start()
    t6.start()
    t7.start()
    t8.start()
    t9.start()
    t10.start()

    t1.join()
    t2.join()
    t3.join()
    t4.join()
    t5.join()
    t6.join()
    t7.join()
    t8.join()
    t9.join()
    t10.join()


